@javax.xml.bind.annotation.XmlSchema(namespace = "http://calculator_maven.calculator.com/")
package client;
